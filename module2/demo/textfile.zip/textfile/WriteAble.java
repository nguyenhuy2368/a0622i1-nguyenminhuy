package codegym.vn.textfile;

public interface WriteAble {
    String getInfo();
    Object inputInfo(String line);
}
